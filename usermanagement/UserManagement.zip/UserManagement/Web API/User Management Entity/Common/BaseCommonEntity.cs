﻿namespace User_Management_Entity.Common
{
    /// <summary>
    /// Class BaseCommonEntity
    /// </summary>
    public class BaseCommonEntity
    {
        /// <summary>
        /// Gets or sets Code
        /// </summary>
        public int Code { get; set; }

        /// <summary>
        /// Gets or sets Message
        /// </summary>
        public string Message { get; set; }
    }
}
