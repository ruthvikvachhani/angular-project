﻿using System.Collections;
namespace User_Management_Core.Services
{
    using Dapper;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using User_Management_Core.Interface;
    using User_Management_Entity;
    using User_Management_Entity.Common;

    /// <summary>
    /// Class UserManagement
    /// </summary>
    public class UserManagement : IUserManagement
    {
        const string sqlConnectionString = "data source=(localdb)\\DEVELOPMENT;initial catalog=KamKaaj;trusted_connection=true";

        /// <summary>
        /// Get the list of all users
        /// </summary>
        /// <returns>
        /// return list of users
        /// </returns>
        public ApiResult<IEnumerable<UserEntity>> GetUsers()
        {
            ApiResult<IEnumerable<UserEntity>> result = new ApiResult<IEnumerable<UserEntity>>();
            var parameters = new DynamicParameters();
            parameters.Add("@Code", result.Code, dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@Message", result.Message, dbType: DbType.String, direction: ParameterDirection.Output, size: int.MaxValue);

            using (IDbConnection con = new SqlConnection(sqlConnectionString))
            {
                var task = con.QueryMultiple("Get_Users", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 60);
                result.Item = task.Read<UserEntity>().ToList();
            }

            result.Message = parameters.Get<string>("@Message");
            result.Code = parameters.Get<int>("@Code");

            return result;
        }

        /// <summary>
        /// Get the user by id
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns>
        /// Users data
        /// </returns>
        public ApiResult<UserEntity> GetUserById(long id)
        {
            ApiResult<UserEntity> result = new ApiResult<UserEntity>();
            var parameters = new DynamicParameters();

            parameters.Add("@UserId", id, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@Code", result.Code, dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@Message", result.Message, dbType: DbType.String, direction: ParameterDirection.Output, size: int.MaxValue);

            using (IDbConnection con = new SqlConnection(sqlConnectionString))
            {
                var task = con.QueryMultiple("Get_Users", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 60);
                result.Item = task.Read<UserEntity>().FirstOrDefault();
            }

            result.Message = parameters.Get<string>("@Message");
            result.Code = parameters.Get<int>("@Code");

            return result;
        }

        /// <summary>
        /// insert new user
        /// </summary>
        /// <param name="userEntity">The user entity</param>
        /// <returns>
        /// Inserted user
        /// </returns>
        public ApiResult<UserEntity> Insert(UserEntity userEntity)
        {
            ApiResult<UserEntity> result = new ApiResult<UserEntity>();
            var parameters = new DynamicParameters();

            parameters.Add("@Code", result.Code, dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@Message", result.Message, dbType: DbType.String, direction: ParameterDirection.Output, size: int.MaxValue);
            parameters.Add("@FirstName", userEntity.FirstName, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@LastName", userEntity.LastName, dbType: DbType.String, direction: ParameterDirection.Input);


            using (IDbConnection con = new SqlConnection(sqlConnectionString))
            {
                var task = con.QueryMultiple("Insert_Users", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 60);
                result.Item = task.Read<UserEntity>().FirstOrDefault();
            }

            result.Message = parameters.Get<string>("@Message");
            result.Code = parameters.Get<int>("@Code");

            return result;
        }

        /// <summary>
        /// Update the user
        /// </summary>
        /// <param name="userEntity">The user entity</param>
        /// <returns>
        /// Updated data
        /// </returns>
        public ApiResult<UserEntity> Update(UserEntity userEntity)
        {
            ApiResult<UserEntity> result = new ApiResult<UserEntity>();
            var parameters = new DynamicParameters();

            parameters.Add("@Code", result.Code, dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@Message", result.Message, dbType: DbType.String, direction: ParameterDirection.Output, size: int.MaxValue);
            parameters.Add("@FirstName", userEntity.FirstName, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@LastName", userEntity.LastName, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@UserId", userEntity.UserId, dbType: DbType.Int64, direction: ParameterDirection.Input);


            using (IDbConnection con = new SqlConnection(sqlConnectionString))
            {
                var task = con.QueryMultiple("Update_Users", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 60);
                result.Item = task.Read<UserEntity>().FirstOrDefault();
            }

            result.Message = parameters.Get<string>("@Message");
            result.Code = parameters.Get<int>("@Code");

            return result;
        }

        /// <summary>
        /// Delete the user
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns>
        /// Deleted data
        /// </returns>
        public ApiResult<UserEntity> Delete(long id)
        {
            ApiResult<UserEntity> result = new ApiResult<UserEntity>();
            var parameters = new DynamicParameters();

            parameters.Add("@Code", result.Code, dbType: DbType.Int32, direction: ParameterDirection.Output);
            parameters.Add("@Message", result.Message, dbType: DbType.String, direction: ParameterDirection.Output, size: int.MaxValue);
            parameters.Add("@UserId", id, dbType: DbType.Int64, direction: ParameterDirection.Input);


            using (IDbConnection con = new SqlConnection(sqlConnectionString))
            {
                var task = con.QueryMultiple("Delete_Users", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 60);
                result.Item = task.Read<UserEntity>().FirstOrDefault();
            }

            result.Message = parameters.Get<string>("@Message");
            result.Code = parameters.Get<int>("@Code");

            return result;
        }
    }
}
