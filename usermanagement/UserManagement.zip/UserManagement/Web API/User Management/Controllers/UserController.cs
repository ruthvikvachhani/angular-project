﻿namespace User_Management.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using User_Management_Core.Interface;
    using User_Management_Entity;
    using User_Management_Entity.Common;

    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("EnableCORS")]
    public class UserController : ControllerBase
    {
        /// <summary>
        /// The IUserManagement
        /// </summary>
        private readonly IUserManagement userManagement;

        /// <summary>
        /// The User Controller
        /// </summary>
        /// <param name="userManagement">The IUserManagement instance</param>
        public UserController(IUserManagement userManagement)
        {
            this.userManagement = userManagement;
        }

        /// <summary>
        /// Get the user list
        /// </summary>
        /// <returns>
        /// return the list of users
        /// </returns>
        [HttpGet]
        [Route("getusers")]
        public IActionResult GetUsers()
        {
            ApiResult<IEnumerable<UserEntity>> result = this.userManagement.GetUsers();
            return this.StatusCode(result.Code, result);
        }

        /// <summary>
        /// Get the user by id
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns>
        /// Users data
        /// </returns>
        [HttpGet]
        [Route("getusers/{id:long}")]
        public IActionResult GetUserById(long id)
        {
            ApiResult<UserEntity> result = this.userManagement.GetUserById(id);
            return this.StatusCode(result.Code, result);
        }

        /// <summary>
        /// Insert the user data
        /// </summary>
        /// <param name="userEntity">The user data</param>
        /// <returns>
        /// Inserted data
        /// </returns>
        [HttpPost]
        [Route("insertuser")]
        public IActionResult InsertUser([FromBody]UserEntity userEntity)
        {
            ApiResult<UserEntity> result = this.userManagement.Insert(userEntity);
            return this.StatusCode(result.Code, result);
        }

        /// <summary>
        /// Update the user data
        /// </summary>
        /// <param name="userEntity">The user data</param>
        /// <returns>
        /// Updated data
        /// </returns>
        [HttpPut]
        [Route("updateuser")]
        public IActionResult UpdateUser([FromBody]UserEntity userEntity)
        {
            ApiResult<UserEntity> result = this.userManagement.Update(userEntity);
            return this.StatusCode(result.Code, result);
        }

        /// <summary>
        /// Delete the user data
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns>
        /// Deleted record
        /// </returns>
        [HttpDelete]
        [Route("deleteuser/{id:long}")]
        public IActionResult DeleteUser([FromRoute]long id)
        {
            ApiResult<UserEntity> result = this.userManagement.Delete(id);
            return this.StatusCode(result.Code, result);
        }
    }
}