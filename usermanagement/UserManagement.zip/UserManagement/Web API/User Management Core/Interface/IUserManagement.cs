﻿namespace User_Management_Core.Interface
{
    using System.Collections.Generic;
    using User_Management_Entity;
    using User_Management_Entity.Common;

    /// <summary>
    /// Interface IUserManagement
    /// </summary>
    public interface IUserManagement
    {
        /// <summary>
        /// Get the list of all users
        /// </summary>
        /// <returns>
        /// return list of users
        /// </returns>
        ApiResult<IEnumerable<UserEntity>> GetUsers();

        /// <summary>
        /// Get the user by id
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns>
        /// Users data
        /// </returns>
        ApiResult<UserEntity> GetUserById(long id);

        /// <summary>
        /// insert new user
        /// </summary>
        /// <param name="userEntity">The user entity</param>
        /// <returns>
        /// Inserted user
        /// </returns>
        ApiResult<UserEntity> Insert(UserEntity userEntity);

        /// <summary>
        /// Update the user
        /// </summary>
        /// <param name="userEntity">The user entity</param>
        /// <returns>
        /// Updated data
        /// </returns>
        ApiResult<UserEntity> Update(UserEntity userEntity);

        /// <summary>
        /// Delete the user
        /// </summary>
        /// <param name="id">The identifier</param>
        /// <returns>
        /// Deleted data
        /// </returns>
        ApiResult<UserEntity> Delete(long id);
    }
}
