﻿namespace User_Management_Entity.Common
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Class ExceptionMiddleware
    /// </summary>
    public class ExceptionMiddleware
    {
        private const string ErrorMessage = "An unexpected error has occurred.";
        private readonly RequestDelegate next;
        private readonly ILogger<ExceptionMiddleware> logger = null;

        public ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
        {
            this.logger = logger;
            this.next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await this.next(httpContext);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, $"Something went wrong: {ex}");
            }
        }
    }
}
