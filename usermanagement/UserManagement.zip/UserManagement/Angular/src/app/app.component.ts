import { Component, Injectable } from '@angular/core';
import { UserRepository } from './Services/User.repository';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'UserManagement';
  displayedColumns: string[] = ['Id', 'firstName', 'lastName', 'Action'];
  dataSource: any;

  userForm = new FormGroup({
    FirstName: new FormControl(''),
    LastName: new FormControl('')
  });

  userId: any
  showForm = false;

  constructor(private userService: UserRepository,
    private toastr: ToastrService
  ) {

  }

  // on page load method call
  ngOnInit() {
    this.getUsers();
  }

  // show and hide the form
  showAddNewUserForm() {
    this.showForm = true;
    this.userId = null;
  }

  //#region DBOperations
  // insert the new user
  insertUser() {
    this.showForm = true;
    const userModel = {
      FirstName: this.userForm.controls.FirstName.value,
      LastName: this.userForm.controls.LastName.value
    }

    this.userService.insertUser(userModel).subscribe((result: any) => {
      this.getUsers();
      this.userForm.reset();
      this.showForm = false;
      this.toastr.success(result.message);
    }, err => {
      this.toastr.error(err);
      console.log(err);
    });
  }

  // delete the user
  confirmDelete(userId) {
    if (confirm('are you sure to delete the user ?')) {
      this.userService.deleteUser(userId).subscribe((result: any) => {
        this.toastr.success(result.message);
        this.getUsers();
      }, err => {
        this.toastr.error(err);
        console.log(err);
      });
    }
  }

  // get the users list
  getUsers() {
    this.userService.getUsers().subscribe((result: any) => {
      console.log(result);
      this.dataSource = result.item;
    }, err => {
      this.toastr.error(err);
      console.log(err);
    });
  }

  // get the specific user detail
  getUserInfo(userId) {
    this.userId = userId;
    this.showForm = true;
    this.userService.getUserById(userId).subscribe((result: any) => {
      const item = result.item;
      this.userForm.patchValue({
        FirstName: item.firstName,
        LastName: item.lastName
      });
    }, err => {
      this.toastr.error(err);
      console.log(err);
    });
  }

  // update the user
  updateUser() {
    const userModel = {
      FirstName: this.userForm.controls.FirstName.value,
      LastName: this.userForm.controls.LastName.value,
      UserId: this.userId
    }

    this.userService.updateUser(userModel).subscribe((result: any) => {
      this.userForm.reset();
      this.getUsers();
      this.showForm = false;
      this.toastr.success(result.message);
    }, err => {
      this.toastr.error(err);
      console.log(err);
    });
  }
  //#endregion
}
