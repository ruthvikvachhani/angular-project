﻿
namespace User_Management_Entity
{

    /// <summary>
    /// Class UserEntity
    /// </summary>
    public class UserEntity
    {
        /// <summary>
        /// Gets or sets UserId
        /// </summary>
        public long UserId { get; set; }

        /// <summary>
        /// Gets or sets FirstName
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets LastName 
        /// </summary>
        public string LastName { get; set; }
    }
}
