import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class UserRepository {

    private userAPIURL = 'https://localhost:44377/api/User'

    constructor(private httpClient: HttpClient) { }

    public getUsers() {
        return this.httpClient.get(this.userAPIURL + '/getusers');
    }

    public getUserById(userId) {
        return this.httpClient.get(this.userAPIURL + '/getusers/' + userId);
    }

    public updateUser(model) {
        return this.httpClient.put(this.userAPIURL + '/updateuser', model);
    }

    public insertUser(model) {
        return this.httpClient.post(this.userAPIURL + '/insertuser', model);
    }

    public deleteUser(userId) {
        return this.httpClient.delete(this.userAPIURL + '/deleteuser/' + userId);
    }
}